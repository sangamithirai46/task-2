★For solving this Task I have try to create one sweet and simple Voice Assistant named as ⚡LAILA⚡ that has an capability to Control my Linux Server or to help someone in following ways :

⚡Basic Linux Commands.

⚡Basic Networking.

⚡Create and Restrict User for Specific Programs.

⚡Configuration of DOCKER.

⚡Hadoop Setup.

⚡Provision of EC-2 Instance.

★ I have also create one simple WebUI , that can also Control my Linux Server.
